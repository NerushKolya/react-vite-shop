export function Error() {
	return <>Error</>;
}