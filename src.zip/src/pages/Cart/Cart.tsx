export function Cart() {
	return <>Cart</>;
}